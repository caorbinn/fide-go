package com.example.fide_go.utils.googleAuth

data class SignInState(
    val isSignInSuccessful: Boolean = false,
    val signInError: String? =null
)
