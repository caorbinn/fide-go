package com.example.fide_go

/**
 * Function to send notification.
 */
class MyFirebaseMessagingService : com.google.firebase.messaging.FirebaseMessagingService() {

}
